//
//  Artwork.swift
//  ArtGalleryApp
//
//  Created by Aayush Raghuvanshi on 3/26/25.
//

struct ArtworkResponse: Codable {
    let data: [Artwork]
}

struct Artwork: Codable, Identifiable, Equatable {
    let id: Int
    let title: String
    let artistDisplay: String?
    let imageId: String?
    let dateDisplay: String?
    let mediumDisplay: String?
    let dimensions: String?
    let departmentTitle: String?   
    
    enum CodingKeys: String, CodingKey {
        case id, title
        case artistDisplay = "artist_display"
        case imageId = "image_id"
        case dateDisplay = "date_display"
        case mediumDisplay = "medium_display"
        case dimensions
        case departmentTitle = "department_title"
    }
}
