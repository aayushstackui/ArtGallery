//
//  UserProfileModel.swift
//  ArtGalleryApp
//
//  Created by Aayush Raghuvanshi on 3/27/25.
//

import Foundation
import SwiftUI

class UserProfile: ObservableObject {
    @Published var name: String = "User Name"
    @Published var bio: String = "Tell us about yourself..."
    @Published var profileImage: UIImage? = nil
    
    func save() {
        UserDefaults.standard.set(name, forKey: "userName")
        UserDefaults.standard.set(bio, forKey: "userBio")
        if let image = profileImage {
            if let imageData = image.jpegData(compressionQuality: 0.8) {
                UserDefaults.standard.set(imageData, forKey: "userProfileImage")
            }
        }
    }
    
    init() {
        name = UserDefaults.standard.string(forKey: "userName") ?? "User Name"
        bio = UserDefaults.standard.string(forKey: "userBio") ?? "Tell us about yourself..."
        if let imageData = UserDefaults.standard.data(forKey: "userProfileImage") {
            profileImage = UIImage(data: imageData)
        }
    }
}
