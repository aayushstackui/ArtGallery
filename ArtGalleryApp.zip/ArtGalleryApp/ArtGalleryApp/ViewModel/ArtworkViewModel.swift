//
//  ArtworkViewModel.swift
//  ArtGalleryApp
//
//  Created by Aayush Raghuvanshi on 3/26/25.
//

import Combine
import Foundation

class ArtworkViewModel: ObservableObject {
    @Published var artworks: [Artwork] = []
    @Published var errorMessage: String?
    @Published var isLoading = false
    
    private let networkService: NetworkServiceProtocol
    private var cancellables = Set<AnyCancellable>()
    
    init(networkService: NetworkServiceProtocol = NetworkService()) {
        self.networkService = networkService
        loadArtworks()
    }
    
    func loadArtworks() {
        if NetworkReachability.isConnected() {
            fetchFromAPI()
        } else {
            fetchFromCache()
            errorMessage = "Offline mode: Showing cached data"
        }
    }
    
    private func fetchFromAPI() {
        isLoading = true
        networkService.fetchArtworks()
            .receive(on: DispatchQueue.main)
            .sink { [weak self] completion in
                self?.isLoading = false
                if case .failure(let error) = completion {
                    self?.errorMessage = error.localizedDescription
                }
            } receiveValue: { [weak self] response in
                self?.artworks = response.data
                self?.errorMessage = nil // Clear error message on success
                CoreDataManager.shared.saveArtworks(response.data)
            }
            .store(in: &cancellables)
    }
    
    private func fetchFromCache() {
        artworks = CoreDataManager.shared.fetchCachedArtworks()
    }
}

struct NetworkReachability {
    static func isConnected() -> Bool { true }
}
