//
//  ArtworkDetailView.swift
//  ArtGalleryApp
//
//  Created by Aayush Raghuvanshi on 3/26/25.
//

import SwiftUI

struct ArtworkDetailView: View {
    let artwork: Artwork
    @State private var isSharing: Bool = false
    @State private var isFavourite: Bool = false
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                AsyncImage(url: URL(string: "https://www.artic.edu/iiif/2/\(artwork.imageId ?? "")/full/843,/0/default.jpg")) { phase in
                    switch phase {
                    case .success(let image):
                        image
                            .resizable()
                            .scaledToFit()
                            .clipShape(RoundedRectangle(cornerRadius: 16))
                            .shadow(color: .gray.opacity(0.3), radius: 10, x: 0, y: 5)
                            .overlay(
                                RoundedRectangle(cornerRadius: 16)
                                    .stroke(LinearGradient(
                                        colors: [.purple.opacity(0.5), .blue.opacity(0.5)],
                                        startPoint: .topLeading,
                                        endPoint: .bottomTrailing
                                    ), lineWidth: 2)
                            )
                    case .empty:
                        ProgressView()
                            .scaleEffect(1.5)
                            .frame(maxWidth: .infinity)
                            .frame(height: 300)
                            .background(Color.gray.opacity(0.1))
                            .clipShape(RoundedRectangle(cornerRadius: 16))
                    case .failure:
                        Image(systemName: "exclamationmark.triangle")
                            .font(.largeTitle)
                            .foregroundColor(.red)
                            .frame(maxWidth: .infinity)
                            .frame(height: 300)
                            .background(Color.gray.opacity(0.1))
                            .clipShape(RoundedRectangle(cornerRadius: 16))
                    @unknown default:
                        EmptyView()
                    }
                }
                .padding(.horizontal)
                .padding(.top)
                
                Button(action: {
                    isFavourite.toggle()
                    CoreDataManager.shared.toggleFavourite(for: artwork)
                }) {
                    Image(systemName: isFavourite ? "star.fill" : "star")
                        .foregroundColor(.yellow)
                        .font(.title)
                        .padding()
                        .background(Circle().fill(Color.white).shadow(radius: 10))
                }
                .padding(.top)
                
                VStack(alignment: .leading, spacing: 8) {
                    Text(artwork.title)
                        .font(.system(size: 28, weight: .bold, design: .serif))
                        .foregroundStyle(
                            LinearGradient(
                                colors: [.purple, .blue],
                                startPoint: .leading,
                                endPoint: .trailing
                            )
                        )
                        .lineLimit(2)
                    
                    Text(artwork.artistDisplay ?? "Unknown Artist")
                        .font(.system(size: 18, weight: .medium, design: .serif))
                        .foregroundColor(.gray)
                        .italic()
                }
                .padding(.horizontal)
                
                VStack(alignment: .leading, spacing: 16) {
                    if let date = artwork.dateDisplay {
                        DetailRow(label: "Date", value: date)
                    }
                    if let medium = artwork.mediumDisplay {
                        DetailRow(label: "Medium", value: medium)
                    }
                    if let dimensions = artwork.dimensions {
                        DetailRow(label: "Dimensions", value: dimensions)
                    }
                    if let department = artwork.departmentTitle {
                        DetailRow(label: "Department", value: department)
                    }
                }
                .padding()
                .background(Color(.systemGray6))
                .clipShape(RoundedRectangle(cornerRadius: 12))
                .shadow(color: .gray.opacity(0.2), radius: 5)
                .padding(.horizontal)
                
                // Step 1: Add a share button
                Button(action: {
                    isSharing.toggle() // Trigger the sharing action
                }) {
                    HStack {
                        Image(systemName: "square.and.arrow.up")
                            .foregroundColor(.purple)
                        Text("Share Artwork")
                            .font(.system(size: 16, weight: .bold, design: .rounded))
                            .foregroundColor(.purple)
                    }
                    .padding()
                    .background(RoundedRectangle(cornerRadius: 12).stroke(LinearGradient(
                        colors: [.purple.opacity(0.5), .blue.opacity(0.5)],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    ), lineWidth: 2))
                }
                .padding(.horizontal)
                
                Spacer()
            }
        }
        .background(
            LinearGradient(
                colors: [.blue.opacity(0.05), .purple.opacity(0.05), .white],
                startPoint: .top,
                endPoint: .bottom
            )
            .ignoresSafeArea()
        )
        .navigationTitle("")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .principal) {
                HStack(spacing: 8) {
                    Image(systemName: "photo.artframe")
                        .foregroundColor(.purple)
                        .shadow(radius: 2)
                    Text("Art Gallery")
                        .font(.system(size: 24, weight: .bold, design: .rounded))
                        .foregroundStyle(
                            LinearGradient(
                                colors: [.purple, .blue],
                                startPoint: .leading,
                                endPoint: .trailing
                            )
                        )
                        .shadow(color: .gray.opacity(0.3), radius: 2, x: 0, y: 2)
                }
                .padding(.vertical, 8)
            }
        }
        .animation(.easeInOut(duration: 0.3), value: artwork)
        .sheet(isPresented: $isSharing) {
            ShareSheet(activityItems: [
                URL(string: "https://www.artic.edu/iiif/2/\(artwork.imageId ?? "")/full/843,/0/default.jpg")!,
                artwork.title
            ])
        }
        .onAppear {
                    // Check if the artwork is a favourite when the detail view is loaded
                    let favourites = CoreDataManager.shared.fetchFavouriteArtworks()
                    isFavourite = favourites.contains { $0.id == artwork.id }
                }
    }
}

// DetailRow for displaying artwork details
struct DetailRow: View {
    let label: String
    let value: String
    
    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            Text(label + ":")
                .font(.system(size: 14, weight: .semibold, design: .rounded))
                .foregroundColor(.purple)
                .frame(width: 90, alignment: .trailing)
            
            Text(value)
                .font(.system(size: 16, design: .rounded))
                .foregroundColor(.primary)
                .multilineTextAlignment(.leading)
        }
        .padding(.vertical, 4)
        .transition(.opacity)
    }
}
