//
//  FavouriteView.swift
//  ArtGalleryApp
//
//  Created by Aayush Raghuvanshi on 3/31/25.
//

import SwiftUI

struct FavouriteView: View {
    @State private var favouriteArtworks: [Artwork] = []
    
    var body: some View {
        NavigationView {
            VStack {
                if favouriteArtworks.isEmpty {
                    Text("No favourites yet.")
                        .foregroundColor(.gray)
                        .font(.headline)
                        .padding()
                } else {
                    List(favouriteArtworks) { artwork in
                        NavigationLink(destination: ArtworkDetailView(artwork: artwork)) {
                            ArtworkRow(artwork: artwork)
                        }
                    }
                    .onAppear {
                        favouriteArtworks = CoreDataManager.shared.fetchFavouriteArtworks()
                    }
                }
            }
            .navigationTitle("Favourites")
        }
    }
}

