//
//  ArtworkListView.swift
//  ArtGalleryApp
//
//  Created by Aayush Raghuvanshi on 3/26/25.
//

import SwiftUI
import Speech

struct ArtworkListView: View {
    @StateObject private var viewModel = ArtworkViewModel()
    @StateObject private var userProfile = UserProfile()
    @State private var displayMode: DisplayMode = .list
    @State private var selectedDestination: Destination? = nil
    @State private var searchText: String = ""
    @State private var isSpeaking: Bool = false
    @State private var speechRecognizer = SpeechRecognizer()
    @FocusState private var isSearchBarFocused: Bool
    
    enum DisplayMode: String, CaseIterable {
        case list = "List"
        case grid = "Grid"
        case compact = "Compact"
    }
    
    enum Destination: String, Hashable {
        case profile
        case settings
    }
    
    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                // search Bar with Mic Button
                HStack {
                    TextField("Search Artworks", text: $searchText)
                        .padding(.leading, 50)
                        .padding(.vertical, 10)
                        .background(Color(.systemGray6))
                        .cornerRadius(10)
                        .focused($isSearchBarFocused) // Bind the TextField focus
                        .overlay(
                            HStack {
                                // Only show the magnifying glass when search bar is not focused
                                if !isSearchBarFocused {
                                    Image(systemName: "magnifyingglass")
                                        .foregroundColor(.gray)
                                        .padding(.leading, 10)
                                }
                                Spacer()
                                if !isSpeaking {
                                    Button(action: startVoiceSearch) {
                                        Image(systemName: "mic.fill")
                                            .foregroundColor(.purple)
                                            .padding(.trailing, 10)
                                    }
                                } else {
                                    ProgressView()
                                        .scaleEffect(1.2)
                                        .padding(.trailing, 10)
                                }
                            }
                                .padding(.horizontal)
                        )
                        .padding(.horizontal)
                }
                .padding(.top)
                
                // Display mode and menu
                HStack {
                    Spacer()
                    Menu {
                        ForEach(DisplayMode.allCases, id: \.self) { mode in
                            Button(action: { displayMode = mode }) {
                                Label(mode.rawValue, systemImage: modeIcon(mode))
                            }
                        }
                    } label: {
                        HStack(spacing: 8) {
                            Image(systemName: modeIcon(displayMode))
                            Text(displayMode.rawValue)
                        }
                        .padding(.horizontal, 12)
                        .padding(.vertical, 6)
                        .background(Color(.systemGray6))
                        .cornerRadius(20)
                    }
                    .foregroundColor(.primary)
                }
                .padding(.horizontal)
                .padding(.vertical, 8)
                .background(Color(.systemGray5).opacity(0.5))
                
                // Handling loading, error, and artwork display
                if viewModel.isLoading {
                    ProgressView()
                        .scaleEffect(1.5)
                        .padding()
                } else if let error = viewModel.errorMessage {
                    Text(error)
                        .foregroundColor(.red)
                        .padding()
                        .background(Color.red.opacity(0.1))
                        .cornerRadius(10)
                        .padding()
                } else {
                    ScrollView {
                        switch displayMode {
                        case .list:
                            LazyVStack(spacing: 12) {
                                ForEach(filteredArtworks) { artwork in
                                    NavigationLink(destination: ArtworkDetailView(artwork: artwork)) {
                                        ArtworkRow(artwork: artwork)
                                    }
                                }
                            }
                            .padding()
                            
                        case .grid:
                            LazyVGrid(columns: [GridItem(.adaptive(minimum: 150), spacing: 12)], spacing: 12) {
                                ForEach(filteredArtworks) { artwork in
                                    NavigationLink(destination: ArtworkDetailView(artwork: artwork)) {
                                        ArtworkGridItem(artwork: artwork)
                                    }
                                }
                            }
                            .padding()
                            
                        case .compact:
                            LazyVStack(spacing: 8) {
                                ForEach(filteredArtworks) { artwork in
                                    NavigationLink(destination: ArtworkDetailView(artwork: artwork)) {
                                        ArtworkCompactItem(artwork: artwork)
                                    }
                                }
                            }
                            .padding()
                        }
                    }
                    .background(Color(.systemBackground))
                    .animation(.spring(), value: displayMode)
                }
            }
            .navigationTitle("")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .principal) {
                    HStack(spacing: 8) {
                        Image(systemName: "photo.artframe")
                            .foregroundColor(.purple)
                            .shadow(radius: 2)
                        
                        Text("Art Gallery")
                            .font(.system(size: 24, weight: .bold, design: .rounded))
                            .foregroundStyle(
                                LinearGradient(
                                    colors: [.purple, .blue],
                                    startPoint: .leading,
                                    endPoint: .trailing
                                )
                            )
                            .shadow(color: .gray.opacity(0.3), radius: 2, x: 0, y: 2)
                    }
                    .padding(.vertical, 8)
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Menu {
                        Button("Profile") {
                            selectedDestination = .profile
                        }
                        Button("Settings") {
                            selectedDestination = .settings
                        }
                    } label: {
                        if let profileImage = userProfile.profileImage {
                            Image(uiImage: profileImage)
                                .resizable()
                                .scaledToFill()
                                .frame(width: 32, height: 32)
                                .clipShape(Circle())
                        } else {
                            Image(systemName: "person.circle")
                                .font(.title2)
                                .foregroundColor(.primary)
                        }
                    }
                }
            }
            .background(
                LinearGradient(
                    gradient: Gradient(colors: [.blue.opacity(0.1), .purple.opacity(0.1)]),
                    startPoint: .top,
                    endPoint: .bottom
                )
            )
            .background(
                Group {
                    NavigationLink(
                        destination: ProfileView(),
                        tag: .profile,
                        selection: $selectedDestination,
                        label: { EmptyView() }
                    )
                    NavigationLink(
                        destination: SettingsView(),
                        tag: .settings,
                        selection: $selectedDestination,
                        label: { EmptyView() }
                    )
                }
            )
        }
    }
    
    // Computed property for filtered artworks based on search text
    private var filteredArtworks: [Artwork] {
        if searchText.isEmpty {
            return viewModel.artworks
        } else {
            return viewModel.artworks.filter { artwork in
                artwork.title.lowercased().contains(searchText.lowercased())
            }
        }
    }
    
    private func modeIcon(_ mode: DisplayMode) -> String {
        switch mode {
        case .list: return "list.bullet"
        case .grid: return "square.grid.2x2"
        case .compact: return "rectangle.grid.1x2"
        }
    }
    
    // Start Voice Search
    private func startVoiceSearch() {
        speechRecognizer.startRecording { result in
            if let recognizedText = result {
                searchText = recognizedText
            }
        }
    }
}

struct ArtworkRow: View {
    let artwork: Artwork
    
    var body: some View {
        HStack(spacing: 12) {
            AsyncImage(url: URL(string: "https://www.artic.edu/iiif/2/\(artwork.imageId ?? "")/full/843,/0/default.jpg")) { image in
                image
                    .resizable()
                    .scaledToFill()
            } placeholder: {
                ProgressView()
                    .frame(width: 50, height: 50)
                    .background(Color.gray.opacity(0.1))
            }
            .frame(width: 50, height: 50)
            .cornerRadius(10)
            .shadow(radius: 2)
            
            VStack(alignment: .leading, spacing: 4) {
                Text(artwork.title)
                    .font(.headline)
                    .foregroundColor(.primary)
                Text(artwork.artistDisplay ?? "Unknown")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
            }
            Spacer()
        }
        .padding()
        .background(Color(.systemBackground))
        .cornerRadius(12)
        .shadow(color: .gray.opacity(0.2), radius: 5, x: 0, y: 2)
    }
}

struct ArtworkGridItem: View {
    let artwork: Artwork
    
    var body: some View {
        VStack(spacing: 8) {
            AsyncImage(url: URL(string: "https://www.artic.edu/iiif/2/\(artwork.imageId ?? "")/full/843,/0/default.jpg")) { image in
                image
                    .resizable()
                    .scaledToFill()
            } placeholder: {
                ProgressView()
                    .frame(height: 150)
                    .background(Color.gray.opacity(0.1))
            }
            .frame(height: 150)
            .cornerRadius(12)
            .shadow(radius: 3)
            
            Text(artwork.title)
                .font(.caption)
                .fontWeight(.semibold)
                .multilineTextAlignment(.center)
                .lineLimit(2)
        }
        .padding(4)
        .background(Color(.systemBackground))
        .cornerRadius(16)
        .shadow(color: .gray.opacity(0.2), radius: 5)
    }
}

struct ArtworkCompactItem: View {
    let artwork: Artwork
    
    var body: some View {
        HStack(spacing: 10) {
            AsyncImage(url: URL(string: "https://www.artic.edu/iiif/2/\(artwork.imageId ?? "")/full/843,/0/default.jpg")) { image in
                image
                    .resizable()
                    .scaledToFill()
            } placeholder: {
                ProgressView()
                    .frame(width: 40, height: 40)
            }
            .frame(width: 40, height: 40)
            .cornerRadius(8)
            
            Text(artwork.title)
                .font(.subheadline)
                .lineLimit(1)
            
            Spacer()
            
            Text(artwork.artistDisplay ?? "Unknown")
                .font(.caption)
                .foregroundColor(.secondary)
                .lineLimit(1)
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 8)
        .background(Color(.systemBackground))
        .cornerRadius(10)
        .shadow(color: .gray.opacity(0.1), radius: 3)
    }
}

// Speech Recognizer class for handling speech input
class SpeechRecognizer: NSObject, SFSpeechRecognizerDelegate {
    private var speechRecognizer = SFSpeechRecognizer(locale: Locale(identifier: "en-US"))
    private var recognitionTask: SFSpeechRecognitionTask?
    private var audioEngine = AVAudioEngine()
    
    override init() {
        super.init()
        speechRecognizer?.delegate = self
    }
    
    func startRecording(completion: @escaping (String?) -> Void) {
        SFSpeechRecognizer.requestAuthorization { authStatus in
            guard authStatus == .authorized else {
                completion(nil)
                return
            }
            
            let request = SFSpeechAudioBufferRecognitionRequest()
            let inputNode = self.audioEngine.inputNode
            inputNode.removeTap(onBus: 0)
            
            self.audioEngine.inputNode.installTap(onBus: 0, bufferSize: 1024, format: inputNode.outputFormat(forBus: 0)) { (buffer, time) in
                request.append(buffer)
            }
            
            do {
                try self.audioEngine.start()
                
                self.recognitionTask = self.speechRecognizer?.recognitionTask(with: request) { result, error in
                    if let result = result {
                        completion(result.bestTranscription.formattedString)
                    } else if let error = error {
                        print("Error recognizing speech: \(error.localizedDescription)")
                        completion(nil)
                    }
                }
            } catch {
                print("Error starting audio engine: \(error.localizedDescription)")
                completion(nil)
            }
        }
    }
}
