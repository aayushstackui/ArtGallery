//
//  SettingsView.swift
//  ArtGalleryApp
//
//  Created by Aayush Raghuvanshi on 3/26/25.
//

import SwiftUI
import FirebaseAuth

struct SettingsView: View {
    @State private var fontSize: Double = 16
    @State private var isDarkMode: Bool = false
    @Environment(\.colorScheme) var colorScheme
    @Environment(\.presentationMode) var presentationMode // To pop the current view
    
    var body: some View {
        NavigationStack {
            HStack(spacing: 8) {
                Image(systemName: "photo.artframe")
                    .foregroundColor(.purple)
                    .shadow(radius: 2)
                
                Text("Art Gallery")
                    .font(.system(size: 24, weight: .bold, design: .rounded))
                    .foregroundStyle(
                        LinearGradient(
                            colors: [.purple, .blue],
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    )
                    .shadow(color: .gray.opacity(0.3), radius: 2, x: 0, y: 2)
            }
            .padding(.vertical, 8)
            
            Form {
                // Appearance Section
                Section(header: Text("Appearance")
                    .font(.headline)
                    .foregroundColor(colorScheme == .dark ? .white : .black)) {
                        VStack(alignment: .leading, spacing: 20) {
                            // Font Size Slider
                            HStack {
                                Text("Font Size: \(Int(fontSize))")
                                    .font(.subheadline)
                                    .foregroundColor(colorScheme == .dark ? .white : .black)
                                Spacer()
                                Text("\(Int(fontSize))")
                                    .font(.body)
                                    .foregroundColor(colorScheme == .dark ? .white : .black)
                            }
                            
                            Slider(value: $fontSize, in: 12...24, step: 1)
                                .accentColor(.blue)
                                .background(Color(colorScheme == .dark ? .black : .white).opacity(0.1))
                                .cornerRadius(10)
                        }
                        
                        // Dark Mode Toggle
                        HStack {
                            Text("Dark Mode")
                                .font(.subheadline)
                                .foregroundColor(colorScheme == .dark ? .white : .black)
                            Spacer()
                            Toggle("", isOn: $isDarkMode)
                                .toggleStyle(SwitchToggleStyle(tint: .blue))
                                .onChange(of: isDarkMode) { newValue in
                                    UIApplication.shared.windows.first?.overrideUserInterfaceStyle = newValue ? .dark : .light
                                }
                        }
                    }
                
                // Account Section
                Section(header: Text("Account")
                    .font(.headline)
                    .foregroundColor(colorScheme == .dark ? .white : .black)) {
                        Button(action: logOut) {
                            HStack {
                                Image(systemName: "rectangle.portrait.and.arrow.right")
                                    .foregroundColor(.red)
                                Text("Log Out")
                                    .fontWeight(.semibold)
                                    .foregroundColor(.red)
                            }
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(Color.red.opacity(0.1))
                            .cornerRadius(10)
                            .shadow(radius: 5)
                        }
                    }
            }
            .listStyle(GroupedListStyle())
            .background(Color(colorScheme == .dark ? .black : .white).edgesIgnoringSafeArea(.all))
        }
        .preferredColorScheme(isDarkMode ? .dark : .light)
    }
    
    // log Out action
    private func logOut() {
        do {
            try Auth.auth().signOut()
            // pop the current view to show the login screen
            presentationMode.wrappedValue.dismiss()
        } catch {
            print("Error signing out: \(error.localizedDescription)")
        }
    }
}
