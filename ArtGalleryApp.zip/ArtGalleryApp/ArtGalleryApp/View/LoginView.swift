//
//  LoginView.swift
//  ArtGalleryApp
//
//  Created by Aayush Raghuvanshi on 3/26/25.
//
import Foundation
import SwiftUI
import FirebaseAuth

struct LoginView: View {
    @State private var email = ""
    @State private var password = ""
    @State private var errorMessage: String?
    @State private var isLoggedIn = false
    
    var body: some View {
        NavigationView {
            ZStack {
                LinearGradient(gradient: Gradient(colors: [.blue.opacity(0.8), .purple.opacity(0.6)]), startPoint: .top, endPoint: .bottom)
                    .edgesIgnoringSafeArea(.all)
                
                VStack(spacing: 30) {
                    HStack{
                        Image(systemName: "photo.artframe")
                            .resizable()
                            .frame(width: 30, height: 25)
                            .foregroundColor(.purple)
                            .shadow(radius: 2)
                        
                        Text("Art Gallery")
                            .font(.system(size: 36, weight: .bold, design: .rounded))
                            .foregroundStyle(
                                LinearGradient(
                                    colors: [.purple, .blue],
                                    startPoint: .leading,
                                    endPoint: .trailing
                                )
                            )
                            .shadow(color: .gray.opacity(0.3), radius: 2, x: 0, y: 2)
                    }
                    Text("Welcome Back!")
                        .font(.system(size: 40, weight: .bold, design: .rounded))
                        .foregroundColor(.white)
                        .shadow(radius: 5)
                    
                    TextField("Email", text: $email)
                        .textFieldStyle(CustomTextFieldStyle())
                        .autocapitalization(.none)
                        .keyboardType(.emailAddress)
                        .frame(width: 290)
                    
                    SecureField("Password", text: $password)
                        .textFieldStyle(CustomTextFieldStyle())
                        .frame(width: 290)
                    
                    if let error = errorMessage {
                        Text(error)
                            .foregroundColor(.red.opacity(0.9))
                            .font(.caption)
                            .padding(.horizontal)
                            .transition(.opacity)
                    }
                    
                    Button(action: signIn) {
                        Text("Sign In")
                            .font(.headline)
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.blue)
                            .cornerRadius(12)
                            .shadow(radius: 5)
                    }
                    .padding(.horizontal, 40)
                    
                    HStack {
                        Text("Don't have an account?")
                            .font(.subheadline)
                            .foregroundColor(.white.opacity(0.9))
                        NavigationLink(destination: SignUpView()) {
                            Text("Sign Up")
                                .font(.subheadline)
                                .foregroundColor(.blue.opacity(0.9))
                                .shadow(radius: 5)
                        }
                    }
                }
                .padding()
            }
            .navigationBarHidden(true)
            .fullScreenCover(isPresented: $isLoggedIn) {
                ArtworkListView()
            }
        }
    }
    
    private func signIn() {
        Auth.auth().signIn(withEmail: email, password: password) { result, error in
            if let error = error {
                withAnimation {
                    errorMessage = error.localizedDescription
                }
            } else {
                isLoggedIn = true
            }
        }
    }
}

struct CustomTextFieldStyle: TextFieldStyle {
    func _body(configuration: TextField<Self._Label>) -> some View {
        configuration
            .padding()
            .background(Color.white.opacity(0.9))
            .cornerRadius(10)
            .shadow(radius: 3)
    }
}

struct LoginView_Previews: PreviewProvider {
    static var previews: some View {
        LoginView()
    }
}
