//
//  SignUpView.swift
//  ArtGalleryApp
//
//  Created by Aayush Raghuvanshi on 3/26/25.
//

import SwiftUI
import FirebaseAuth

struct SignUpView: View {
    @State private var email = ""
    @State private var password = ""
    @State private var errorMessage: String?
    @State private var isSignedUp = false
    
    var body: some View {
        ZStack {
            LinearGradient(gradient: Gradient(colors: [.purple.opacity(0.8), .pink.opacity(0.6)]), startPoint: .top, endPoint: .bottom)
                .edgesIgnoringSafeArea(.all)
            
            VStack(spacing: 30) {
                HStack{
                    Image(systemName: "photo.artframe")
                        .resizable()
                        .frame(width: 30, height: 25)
                        .foregroundColor(.purple)
                        .shadow(radius: 2)
                    
                    Text("Art Gallery")
                        .font(.system(size: 36, weight: .bold, design: .rounded))
                        .foregroundStyle(
                            LinearGradient(
                                colors: [.purple, .blue],
                                startPoint: .leading,
                                endPoint: .trailing
                            )
                        )
                        .shadow(color: .gray.opacity(0.3), radius: 2, x: 0, y: 2)
                }
                Text("Hi There!")
                    .font(.system(size: 40, weight: .bold, design: .rounded))
                    .foregroundColor(.white)
                    .shadow(radius: 5)
                
                TextField("Email", text: $email)
                    .textFieldStyle(CustomTextFieldStyle())
                    .autocapitalization(.none)
                    .keyboardType(.emailAddress)
                    .frame(width: 290)
                
                SecureField("Password", text: $password)
                    .textFieldStyle(CustomTextFieldStyle())
                    .frame(width: 290)
                
                if let error = errorMessage {
                    Text(error)
                        .foregroundColor(.red.opacity(0.9))
                        .font(.caption)
                        .padding(.horizontal)
                        .transition(.opacity)
                }
                
                Button(action: signUp) {
                    Text("Sign Up")
                        .font(.headline)
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.purple)
                        .cornerRadius(12)
                        .shadow(radius: 5)
                }
                .padding(.horizontal, 40)
                
                HStack(spacing: 10) {
                    Rectangle()
                        .frame(height: 1)
                        .foregroundColor(.white.opacity(0.5))
                    Text("OR")
                        .foregroundColor(.white.opacity(0.8))
                        .font(.caption)
                    Rectangle()
                        .frame(height: 1)
                        .foregroundColor(.white.opacity(0.5))
                }
                .padding(.horizontal, 40)
                
                VStack(spacing: 10) {
                    Text("Sign up with")
                        .foregroundColor(.white.opacity(0.9))
                        .font(.subheadline)
                    
                    HStack(spacing: 20) {
                        Button(action: {}) {
                            Image("google_logo")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 40, height: 40)
                                .background(Circle().fill(Color.white))
                                .clipShape(Circle())
                                .shadow(radius: 3)
                        }
                        
                        Button(action: {}) {
                            Image("apple_logo")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 40, height: 40)
                                .clipShape(Circle())
                                .shadow(radius: 3)
                        }
                        
                        Button(action: {}) {
                            Image("fb_logo")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 40, height: 40)
                                .background(Circle().fill(Color.white))
                                .clipShape(Circle())
                                .shadow(radius: 3)
                        }
                    }
                }
                
                HStack {
                    Text("Have an account?")
                        .font(.subheadline)
                        .foregroundColor(.white.opacity(0.9))
                    NavigationLink(destination: LoginView()) {
                        Text("Login Now")
                            .font(.subheadline)
                            .foregroundColor(.purple.opacity(0.9))
                            .shadow(radius: 5)
                    }
                }
            }
            .padding()
        }
        .navigationBarHidden(true)
        .fullScreenCover(isPresented: $isSignedUp) {
            ArtworkListView()
        }
    }
    
    private func signUp() {
        Auth.auth().createUser(withEmail: email, password: password) { result, error in
            if let error = error {
                withAnimation {
                    errorMessage = error.localizedDescription
                }
            } else {
                Auth.auth().signIn(withEmail: email, password: password) { _, _ in
                    isSignedUp = true
                }
            }
        }
    }
}

struct SignUpView_Previews: PreviewProvider {
    static var previews: some View {
        SignUpView()
    }
}
