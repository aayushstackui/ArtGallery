//
//  ShareSheet.swift
//  ArtGalleryApp
//
//  Created by Aayush Raghuvanshi on 3/31/25.
//

import SwiftUI
import UIKit

struct ShareSheet: UIViewControllerRepresentable {
    let activityItems: [Any]
    
    // coordinator class
    class Coordinator: NSObject {
        var parent: ShareSheet
        
        init(parent: ShareSheet) {
            self.parent = parent
        }
    }

    func makeUIViewController(context: Context) -> UIActivityViewController {
        let activityViewController = UIActivityViewController(activityItems: activityItems, applicationActivities: nil)
        
        // for iPad, we need to specify a source rect for the popover
        if let popoverController = activityViewController.popoverPresentationController {
            // set the source view for iPad popover behavior
            popoverController.sourceView = UIApplication.shared.windows.first?.rootViewController?.view
            popoverController.sourceRect = CGRect(x: UIScreen.main.bounds.midX, y: UIScreen.main.bounds.midY, width: 1, height: 1)
        }
        
        return activityViewController
    }

    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}

    // create coordinator
    func makeCoordinator() -> Coordinator {
        return Coordinator(parent: self)
    }
}
