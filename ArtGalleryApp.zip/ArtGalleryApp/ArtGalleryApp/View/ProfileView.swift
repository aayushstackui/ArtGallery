//
//  ProfileView.swift
//  ArtGalleryApp
//
//  Created by Aayush Raghuvanshi on 3/26/25.
//

import SwiftUI

struct ProfileView: View {
    @ObservedObject private var userProfile = UserProfile()
    @State private var isEditingName = false
    @State private var isEditingBio = false
    @State private var showingImagePicker = false
    
    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                // Profile Picture Section
                HStack(spacing: 8) {
                    Image(systemName: "photo.artframe")
                        .foregroundColor(.purple)
                        .shadow(radius: 2)
                    
                    Text("Art Gallery")
                        .font(.system(size: 24, weight: .bold, design: .rounded))
                        .foregroundStyle(
                            LinearGradient(
                                colors: [.purple, .blue],
                                startPoint: .leading,
                                endPoint: .trailing
                            )
                        )
                        .shadow(color: .gray.opacity(0.3), radius: 2, x: 0, y: 2)
                }
                .padding(.vertical, 8)
                
                VStack {
                    if let profileImage = userProfile.profileImage {
                        Image(uiImage: profileImage)
                            .resizable()
                            .scaledToFill()
                            .frame(width: 120, height: 120)
                            .clipShape(Circle())
                            .overlay(Circle().stroke(Color.blue, lineWidth: 4))
                            .shadow(radius: 10)
                    } else {
                        Image(systemName: "person.circle.fill")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 120, height: 120)
                            .foregroundColor(.gray)
                    }
                    
                    Button(action: {
                        showingImagePicker = true
                    }) {
                        Text("Change Profile Picture")
                            .fontWeight(.semibold)
                            .foregroundColor(.blue)
                            .padding(.top, 10)
                    }
                    .frame(maxWidth: .infinity)
                }
                .padding(.top, 40)
                
                // Personal Info Section
                VStack(spacing: 15) {
                    // Name Field
                    HStack {
                        if isEditingName {
                            TextField("Enter Name", text: $userProfile.name)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                                .padding()
                                .background(Color.white)
                                .cornerRadius(10)
                                .shadow(radius: 5)
                                .onSubmit {
                                    isEditingName = false
                                    userProfile.save()
                                }
                        } else {
                            Text(userProfile.name)
                                .font(.title2)
                                .fontWeight(.bold)
                                .padding()
                            
                            Button("Edit") {
                                isEditingName = true
                            }
                            .foregroundColor(.blue)
                            .padding(.trailing, 10)
                        }
                    }
                    
                    // Bio Field
                    VStack(alignment: .leading) {
                        if isEditingBio {
                            TextEditor(text: $userProfile.bio)
                                .frame(height: 150)
                                .padding()
                                .background(Color.white)
                                .cornerRadius(10)
                                .shadow(radius: 5)
                                .onSubmit {
                                    isEditingBio = false
                                    userProfile.save()
                                }
                        } else {
                            Text(userProfile.bio.isEmpty ? "Write a bio..." : userProfile.bio)
                                .font(.body)
                                .foregroundColor(userProfile.bio.isEmpty ? .gray : .primary)
                                .padding()
                            
                            Button("Edit Bio") {
                                isEditingBio = true
                            }
                            .foregroundColor(.blue)
                            .padding(.trailing, 10)
                        }
                    }
                    .padding(.top, 10)
                }
                .padding(.horizontal, 20)
                .background(Color(.systemGray6))
                .cornerRadius(15)
                .shadow(radius: 10)
                .padding(.top, 20)
            }
        }
        .navigationTitle("Profile")
        .sheet(isPresented: $showingImagePicker) {
            ImagePicker(image: $userProfile.profileImage)
        }
        .onChange(of: userProfile.profileImage) { _ in
            userProfile.save()
        }
        .padding(.bottom, 20)
    }
}

struct ImagePicker: UIViewControllerRepresentable {
    @Binding var image: UIImage?
    @Environment(\.presentationMode) var presentationMode
    
    func makeUIViewController(context: Context) -> UIImagePickerController {
        let picker = UIImagePickerController()
        picker.delegate = context.coordinator
        return picker
    }
    
    func updateUIViewController(_ uiViewController: UIImagePickerController, context: Context) {}
    
    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }
    
    class Coordinator: NSObject, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
        let parent: ImagePicker
        
        init(_ parent: ImagePicker) {
            self.parent = parent
        }
        
        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
            if let uiImage = info[.originalImage] as? UIImage {
                parent.image = uiImage
            }
            parent.presentationMode.wrappedValue.dismiss()
        }
    }
}
