//
//  MainTabView.swift
//  ArtGalleryApp
//
//  Created by Aayush Raghuvanshi on 3/31/25.
//

import SwiftUI

struct MainTabView: View {
    var body: some View {
        TabView {
            ArtworkListView()
                .tabItem {
                    Image(systemName: "list.bullet")
                    Text("Artworks")
                }
            
            FavouriteView()
                .tabItem {
                    Image(systemName: "star.fill")
                    Text("Favourites")
                }
        }
    }
}

