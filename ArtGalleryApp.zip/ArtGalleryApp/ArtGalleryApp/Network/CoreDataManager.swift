//
//  CoreDataManager.swift
//  ArtGalleryApp
//
//  Created by Aayush Raghuvanshi on 3/26/25.
//

import CoreData

class CoreDataManager {
    static let shared = CoreDataManager()
    let persistentContainer: NSPersistentContainer
    
    private init() {
        persistentContainer = NSPersistentContainer(name: "ArtGalleryModel")
        persistentContainer.loadPersistentStores { _, error in
            if let error = error {
                fatalError("Failed to load Core Data: \(error)")
            }
        }
    }
    
    func saveArtworks(_ artworks: [Artwork]) {
        let context = persistentContainer.viewContext
        for artwork in artworks {
            let entity = NSEntityDescription.insertNewObject(forEntityName: "CachedArtwork", into: context) as! CachedArtwork
            entity.id = Int32(artwork.id)
            entity.title = artwork.title
            entity.artistDisplay = artwork.artistDisplay
            entity.imageId = artwork.imageId
            entity.dateDisplay = artwork.dateDisplay
            entity.mediumDisplay = artwork.mediumDisplay
            entity.dimensions = artwork.dimensions
            entity.departmentTitle = artwork.departmentTitle
            entity.isFavourite = false // New attribute for favourites
        }
        do {
            try context.save()
        } catch {
            print("Failed to save artworks: \(error)")
        }
    }
    
    func fetchCachedArtworks() -> [Artwork] {
        let context = persistentContainer.viewContext
        let request = NSFetchRequest<CachedArtwork>(entityName: "CachedArtwork")
        guard let objects = try? context.fetch(request) else { return [] }
        return objects.map {
            Artwork(id: Int($0.id),
                    title: $0.title!,
                    artistDisplay: $0.artistDisplay,
                    imageId: $0.imageId,
                    dateDisplay: $0.dateDisplay,
                    mediumDisplay: $0.mediumDisplay,
                    dimensions: $0.dimensions,
                    departmentTitle: $0.departmentTitle)
        }
    }
    
    // Fetch favourite artworks
    func fetchFavouriteArtworks() -> [Artwork] {
        let context = persistentContainer.viewContext
        let request: NSFetchRequest<CachedArtwork> = CachedArtwork.fetchRequest()
        request.predicate = NSPredicate(format: "isFavourite == %@", NSNumber(value: true))
        guard let objects = try? context.fetch(request) else { return [] }
        return objects.map {
            Artwork(id: Int($0.id),
                    title: $0.title!,
                    artistDisplay: $0.artistDisplay,
                    imageId: $0.imageId,
                    dateDisplay: $0.dateDisplay,
                    mediumDisplay: $0.mediumDisplay,
                    dimensions: $0.dimensions,
                    departmentTitle: $0.departmentTitle)
        }
    }
    
    // Mark artwork as favourite
    func toggleFavourite(for artwork: Artwork) {
        let context = persistentContainer.viewContext
        let request: NSFetchRequest<CachedArtwork> = CachedArtwork.fetchRequest()
        request.predicate = NSPredicate(format: "id == %@", NSNumber(value: artwork.id))
        
        if let object = try? context.fetch(request).first {
            object.isFavourite.toggle()
            do {
                try context.save()
            } catch {
                print("Failed to toggle favourite: \(error)")
            }
        }
    }
}
