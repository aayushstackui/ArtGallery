//
//  NetworkService.swift
//  ArtGalleryApp
//
//  Created by Aayush Raghuvanshi on 3/26/25.
//

import Combine
import Foundation

enum NetworkError: Error {
    case invalidURL
    case requestFailed(String)
    case decodingError
}

protocol NetworkServiceProtocol {
    func fetchArtworks() -> AnyPublisher<ArtworkResponse, NetworkError>
}

protocol URLSessionProtocol {
    func dataTaskPublisher(for url: URL) -> URLSession.DataTaskPublisher
}

class NetworkService: NetworkServiceProtocol {
    private let session: URLSessionProtocol
    private let baseURL = "https://api.artic.edu/api/v1/artworks?fields=id,title,artist_display,image_id,date_display,medium_display,dimensions,department_title"
    
    init(session: URLSessionProtocol = URLSession.shared) {
        self.session = session
    }

    func fetchArtworks() -> AnyPublisher<ArtworkResponse, NetworkError> {
        guard let url = URL(string: baseURL) else {
            return Fail(error: .invalidURL).eraseToAnyPublisher()
        }
        
        return session.dataTaskPublisher(for: url)
            .mapError { NetworkError.requestFailed($0.localizedDescription) }
            .flatMap { data, response -> AnyPublisher<ArtworkResponse, NetworkError> in
                guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
                    return Fail(error: .requestFailed("Invalid response")).eraseToAnyPublisher()
                }
                return Just(data)
                    .decode(type: ArtworkResponse.self, decoder: JSONDecoder())
                    .mapError { _ in NetworkError.decodingError }
                    .eraseToAnyPublisher()
            }
            .eraseToAnyPublisher()
    }
}

extension URLSession: URLSessionProtocol {}
