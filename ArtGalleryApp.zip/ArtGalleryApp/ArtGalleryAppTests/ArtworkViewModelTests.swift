//
//  ArtworkViewModelTests.swift
//  ArtGalleryAppTests
//
//  Created by Aayush Raghuvanshi on 3/31/25.
//

import XCTest
@testable import ArtGalleryApp
import Combine

class ArtworkViewModelTests: XCTestCase {
    var viewModel: ArtworkViewModel!
    var mockNetworkService: MockNetworkService!
    var cancellables: Set<AnyCancellable>!
    
    override func setUp() {
        super.setUp()
        mockNetworkService = MockNetworkService()
        viewModel = ArtworkViewModel(networkService: mockNetworkService)
        cancellables = Set<AnyCancellable>()
    }
    
    override func tearDown() {
        viewModel = nil
        mockNetworkService = nil
        cancellables = nil
        super.tearDown()
    }
    
    func testLoadArtworksSuccess() {
        // Given
        let expectedArtworks = [
            Artwork(
                id: 1,
                title: "Test Artwork",
                artistDisplay: "Test Artist",
                imageId: "test-id",
                dateDisplay: "2023",
                mediumDisplay: "Oil",
                dimensions: "10x10",
                departmentTitle: "Painting"
            )
        ]
        let response = ArtworkResponse(data: expectedArtworks)
        mockNetworkService.stubbedResult = .success(response)
        
        // When
        let expectation = XCTestExpectation(description: "Artworks loaded")
        viewModel.$artworks
            .dropFirst()
            .sink { artworks in
                expectation.fulfill()
            }
            .store(in: &cancellables)
        
        viewModel.loadArtworks()
        
        // Then
        wait(for: [expectation], timeout: 1.0)
        XCTAssertEqual(viewModel.artworks.count, expectedArtworks.count)
        XCTAssertEqual(viewModel.artworks, expectedArtworks)
        XCTAssertFalse(viewModel.isLoading)
        XCTAssertNil(viewModel.errorMessage, "errorMessage should be nil on success")
    }
    
    func testLoadArtworksFailure() {
        // Given
        mockNetworkService.stubbedResult = .failure(.decodingError)
        
        // When
        let expectation = XCTestExpectation(description: "Error received")
        viewModel.$errorMessage
            .dropFirst()
            .sink { error in
                if error != nil {
                    expectation.fulfill()
                }
            }
            .store(in: &cancellables)
        
        viewModel.loadArtworks()
        
        // Then
        wait(for: [expectation], timeout: 1.0)
        XCTAssertTrue(viewModel.artworks.isEmpty)
        XCTAssertFalse(viewModel.isLoading)
        XCTAssertNotNil(viewModel.errorMessage)
    }
}

class MockNetworkService: NetworkServiceProtocol {
    var stubbedResult: Result<ArtworkResponse, NetworkError>?
    
    func fetchArtworks() -> AnyPublisher<ArtworkResponse, NetworkError> {
        guard let result = stubbedResult else {
            return Fail(error: NetworkError.requestFailed("No stubbed result"))
                .eraseToAnyPublisher()
        }
        switch result {
        case .success(let response):
            return Just(response)
                .setFailureType(to: NetworkError.self)
                .eraseToAnyPublisher()
        case .failure(let error):
            return Fail(error: error)
                .eraseToAnyPublisher()
        }
    }
}
