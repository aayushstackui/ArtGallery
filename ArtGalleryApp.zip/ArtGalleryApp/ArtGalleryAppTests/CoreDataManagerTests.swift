//
//  CoreDataManagerTests.swift
//  ArtGalleryAppTests
//
//  Created by Aayush Raghuvanshi on 3/31/25.
//

import XCTest
@testable import ArtGalleryApp
import CoreData

class CoreDataManagerTests: XCTestCase {
    var coreDataManager: CoreDataManager!
    
    override func setUp() {
        super.setUp()
        coreDataManager = CoreDataManager.shared
        clearCoreData()
    }
    
    func testSaveAndFetchArtworks() {
        // Given
        let artworks = [Artwork(id: 1, title: "Test", artistDisplay: "Artist",
                              imageId: "img1", dateDisplay: "2023", mediumDisplay: "Oil",
                              dimensions: "10x10", departmentTitle: "Painting")]
        
        // When
        coreDataManager.saveArtworks(artworks)
        let fetchedArtworks = coreDataManager.fetchCachedArtworks()
        
        // Then
        XCTAssertEqual(fetchedArtworks.count, 1)
        XCTAssertEqual(fetchedArtworks[0].id, artworks[0].id)
        XCTAssertEqual(fetchedArtworks[0].title, artworks[0].title)
    }
    
    func testToggleFavourite() {
        // Given
        let artwork = Artwork(id: 1, title: "Test", artistDisplay: "Artist",
                            imageId: "img1", dateDisplay: "2023", mediumDisplay: "Oil",
                            dimensions: "10x10", departmentTitle: "Painting")
        coreDataManager.saveArtworks([artwork])
        
        // When
        coreDataManager.toggleFavourite(for: artwork)
        let favourites = coreDataManager.fetchFavouriteArtworks()
        
        // Then
        XCTAssertEqual(favourites.count, 1)
        XCTAssertEqual(favourites[0].id, artwork.id)
    }
    
    private func clearCoreData() {
        let context = coreDataManager.persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "CachedArtwork")
        let deleteRequest = NSBatchDeleteRequest(fetchRequest: fetchRequest)
        try? context.execute(deleteRequest)
    }
}
