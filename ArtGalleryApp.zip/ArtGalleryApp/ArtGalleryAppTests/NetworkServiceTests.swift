//
//  NetworkServiceTests.swift
//  ArtGalleryAppTests
//
//  Created by Aayush Raghuvanshi on 3/31/25.
//

//import XCTest
//@testable import ArtGalleryApp
//import Combine
//
//class NetworkServiceTests: XCTestCase {
//    var networkService: NetworkService!
//    var mockSession: MockURLSession!
//    
//    override func setUp() {
//        super.setUp()
//        mockSession = MockURLSession()
//        networkService = NetworkService(session: mockSession)
//    }
//    
//    func testFetchArtworksSuccess() {
//        // Given
//        let artwork = Artwork(
//            id: 1,
//            title: "Test",
//            artistDisplay: "Artist",
//            imageId: "img1",
//            dateDisplay: "2023",
//            mediumDisplay: "Oil",
//            dimensions: "10x10",
//            departmentTitle: "Painting"
//        )
//        let response = ArtworkResponse(data: [artwork])
//        let data = try! JSONEncoder().encode(response)
//        mockSession.stubbedData = data
//        mockSession.stubbedResponse = HTTPURLResponse(
//            url: URL(string: "https://api.artic.edu")!,
//            statusCode: 200,
//            httpVersion: nil,
//            headerFields: nil
//        )
//        
//        // When
//        var result: Result<ArtworkResponse, NetworkError>?
//        let expectation = XCTestExpectation(description: "Fetch artworks")
//        networkService.fetchArtworks()
//            .sink(
//                receiveCompletion: { completion in
//                    if case .failure = completion {
//                        XCTFail("Expected success but got failure")
//                    }
//                },
//                receiveValue: { response in
//                    result = .success(response)
//                    expectation.fulfill()
//                }
//            )
//            .store(in: &mockSession.cancellables)
//        
//        // Then
//        wait(for: [expectation], timeout: 1.0)
//        switch result {
//        case .success(let response):
//            XCTAssertEqual(response.data.count, 1)
//            XCTAssertEqual(response.data[0].id, artwork.id)
//            XCTAssertEqual(response.data[0].title, artwork.title)
//        case .none:
//            XCTFail("Expected success but got no result")
//        case .failure:
//            XCTFail("Expected success but got failure")
//        }
//    }
//}
//
//class MockURLSession: URLSessionProtocol {
//    var stubbedData: Data?
//    var stubbedResponse: URLResponse?
//    var cancellables = Set<AnyCancellable>()
//    
//    func dataTaskPublisher(for url: URL) -> URLSession.DataTaskPublisher {
//        guard let data = stubbedData,
//              let response = stubbedResponse else {
//            // Explicitly specify the Output type for Fail
//            return Fail<(data: Data, response: URLResponse), URLError>(error: URLError(.badServerResponse))
//                .eraseToAnyPublisher() as! URLSession.DataTaskPublisher
//        }
//        
//        // Create a publisher that matches URLSession.DataTaskPublisher's signature
//        return Just<(data: Data, response: URLResponse)>((data: data, response: response))
//            .setFailureType(to: URLError.self)
//            .eraseToAnyPublisher() as! URLSession.DataTaskPublisher
//    }
//}
